import React from 'react'

export default function Footer() {
    return (
        <div>

            <h3>@FoodHub</h3>
            
        </div>
    )
}
